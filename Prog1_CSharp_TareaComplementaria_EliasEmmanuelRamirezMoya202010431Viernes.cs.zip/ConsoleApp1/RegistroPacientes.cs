﻿//Elias Emmanuel Ramirez Moya 2020-10431

using System;
using System.Collections.Generic;

public class RegistroPacientes
{
    private List<Paciente> pacientes = new List<Paciente>();
    private int contadorId = 1;

    public void Ejecutar()
    {
        Console.WriteLine("Sistema de Registro de Pacientes");

        bool activo = true;
        while (activo)
        {
            Console.WriteLine(@"
1. Agregar Paciente
2. Ver Pacientes
3. Buscar Paciente
4. Modificar Paciente
5. Eliminar Paciente
6. Salir");
            Console.Write("Seleccione una opción: ");

            if (!int.TryParse(Console.ReadLine(), out int opcion))
            {
                Console.WriteLine("Opción inválida.");
                continue;
            }

            switch (opcion)
            {
                case 1: Agregar(); break;
                case 2: Ver(); break;
                case 3: Buscar(); break;
                case 4: Modificar(); break;
                case 5: Eliminar(); break;
                case 6: activo = false; break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    private void Agregar()
    {
        var paciente = new Paciente();
        paciente.Id = contadorId++;

        Console.Write("Nombre: ");
        paciente.Nombre = Console.ReadLine() ?? "";

        Console.Write("Edad: ");
        paciente.Edad = int.TryParse(Console.ReadLine(), out int edad) ? edad : 0;

        Console.Write("Teléfono: ");
        paciente.Telefono = Console.ReadLine() ?? "";

        Console.Write("Dirección: ");
        paciente.Direccion = Console.ReadLine() ?? "";

        Console.Write("Diagnóstico: ");
        paciente.Diagnostico = Console.ReadLine() ?? "";

        pacientes.Add(paciente);
        Console.WriteLine("Paciente agregado exitosamente.\n");
    }

    private void Ver()
    {
        Console.WriteLine("ID | Nombre | Edad | Teléfono | Dirección | Diagnóstico");
        Console.WriteLine("--------------------------------------------------------");
        foreach (var p in pacientes)
        {
            Console.WriteLine($"{p.Id} | {p.Nombre} | {p.Edad} | {p.Telefono} | {p.Direccion} | {p.Diagnostico}");
        }
    }

    private void Buscar()
    {
        Console.Write("Ingrese el ID del paciente: ");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        var paciente = pacientes.Find(p => p.Id == id);
        if (paciente == null)
        {
            Console.WriteLine("Paciente no encontrado.");
            return;
        }

        Console.WriteLine($"Nombre: {paciente.Nombre}");
        Console.WriteLine($"Edad: {paciente.Edad}");
        Console.WriteLine($"Teléfono: {paciente.Telefono}");
        Console.WriteLine($"Dirección: {paciente.Direccion}");
        Console.WriteLine($"Diagnóstico: {paciente.Diagnostico}");
    }

    private void Modificar()
    {
        Console.Write("Ingrese el ID del paciente a modificar: ");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        var paciente = pacientes.Find(p => p.Id == id);
        if (paciente == null)
        {
            Console.WriteLine("Paciente no encontrado.");
            return;
        }

        Console.Write("Nuevo nombre: ");
        paciente.Nombre = Console.ReadLine() ?? "";

        Console.Write("Nueva edad: ");
        paciente.Edad = int.TryParse(Console.ReadLine(), out int edad) ? edad : paciente.Edad;

        Console.Write("Nuevo teléfono: ");
        paciente.Telefono = Console.ReadLine() ?? "";

        Console.Write("Nueva dirección: ");
        paciente.Direccion = Console.ReadLine() ?? "";

        Console.Write("Nuevo diagnóstico: ");
        paciente.Diagnostico = Console.ReadLine() ?? "";

        Console.WriteLine("Paciente modificado exitosamente.");
    }

    private void Eliminar()
    {
        Console.Write("Ingrese el ID del paciente a eliminar: ");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        pacientes.RemoveAll(p => p.Id == id);
        Console.WriteLine("Paciente eliminado.");
    }
}