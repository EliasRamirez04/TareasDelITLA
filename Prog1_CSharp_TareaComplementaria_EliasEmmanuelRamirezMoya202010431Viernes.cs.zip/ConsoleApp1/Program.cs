﻿class Program
{
    static void Main()
    {
        RegistroPacientes sistema = new RegistroPacientes();
        sistema.Ejecutar();
    }
}