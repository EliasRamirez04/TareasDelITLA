﻿class Program
{
    static void Main()
    {
        Agenda agenda = new Agenda();
        agenda.Ejecutar();
    }
}