﻿//Elias Emmanuel Ramirez Moya 2020-10431

using System;
using System.Collections.Generic;

public class Agenda
{
    private List<Contacto> contactos = new List<Contacto>();
    private int contadorId = 1;

    public void Ejecutar()
    {
        Console.WriteLine("Mi Agenda Perrón");
        Console.WriteLine("Bienvenido a tu lista de contactes");

        bool running = true;
        while (running)
        {
            Console.Write("1. Agregar Contacto      ");
            Console.Write("2. Ver Contactos     ");
            Console.Write("3. Buscar Contactos      ");
            Console.Write("4. Modificar Contacto        ");
            Console.Write("5. Eliminar Contacto     ");
            Console.WriteLine("6. Salir");
            Console.Write("Elige una opción: ");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("Opción inválida.");
                continue;
            }

            switch (choice)
            {
                case 1: Agregar(); break;
                case 2: Ver(); break;
                case 3: Buscar(); break;
                case 4: Editar(); break;
                case 5: Eliminar(); break;
                case 6: running = false; break;
                default: Console.WriteLine("Opción no válida"); break;
            }
        }
    }

    private void Agregar()
    {
        Console.WriteLine("Vamos a agregar ese contacte que te trae loco.");

        var contacto = new Contacto();
        contacto.Id = contadorId++;

        Console.Write("Digite el Nombre: ");
        contacto.Nombre = Console.ReadLine() ?? "";

        Console.Write("Digite el Teléfono: ");
        contacto.Telefono = Console.ReadLine() ?? "";

        Console.Write("Digite el Email: ");
        contacto.Email = Console.ReadLine() ?? "";

        Console.Write("Digite la dirección: ");
        contacto.Direccion = Console.ReadLine() ?? "";

        contactos.Add(contacto);
        Console.WriteLine();
    }

    private void Ver()
    {
        Console.WriteLine("Id           Nombre          Telefono            Email           Dirección");
        Console.WriteLine("___________________________________________________________________________");

        foreach (var c in contactos)
        {
            Console.WriteLine($"{c.Id}    {c.Nombre}      {c.Telefono}      {c.Email}     {c.Direccion}");
        }
    }

    private void Editar()
    {
        Ver();
        Console.WriteLine("Digite un Id de Contacto Para Editar");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        var contacto = contactos.Find(c => c.Id == id);
        if (contacto == null)
        {
            Console.WriteLine("Contacto no encontrado.");
            return;
        }

        Console.Write($"El nombre es: {contacto.Nombre}, Digite el Nuevo Nombre: ");
        contacto.Nombre = Console.ReadLine() ?? "";

        Console.Write($"El Teléfono es: {contacto.Telefono}, Digite el Nuevo Teléfono: ");
        contacto.Telefono = Console.ReadLine() ?? "";

        Console.Write($"El Email es: {contacto.Email}, Digite el Nuevo Email: ");
        contacto.Email = Console.ReadLine() ?? "";

        Console.Write($"La dirección es: {contacto.Direccion}, Digite la nueva dirección: ");
        contacto.Direccion = Console.ReadLine() ?? "";

        Console.WriteLine("Contacto modificado.");
    }

    private void Eliminar()
    {
        Ver();
        Console.WriteLine("Digite un Id de Contacto Para Eliminar");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        Console.WriteLine("Seguro que desea eliminar? 1. Si, 2. No");
        if (Console.ReadLine() == "1")
        {
            contactos.RemoveAll(c => c.Id == id);
            Console.WriteLine("Contacto eliminado.");
        }
    }

    private void Buscar()
    {
        Console.WriteLine("Digite un Id de Contacto Para Mostrar");
        if (!int.TryParse(Console.ReadLine(), out int id)) return;

        var contacto = contactos.Find(c => c.Id == id);
        if (contacto == null)
        {
            Console.WriteLine("Contacto no encontrado.");
            return;
        }

        Console.WriteLine($"Nombre: {contacto.Nombre}");
        Console.WriteLine($"Teléfono: {contacto.Telefono}");
        Console.WriteLine($"Email: {contacto.Email}");
        Console.WriteLine($"Dirección: {contacto.Direccion}");
    }
}